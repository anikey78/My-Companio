# MyCompanio

A mental health companion chatbot built with React (frontend) and Express (backend).

## Setup

### Frontend
```bash
cd client
npm install
npm run dev
```

### Backend
```bash
cd server
npm install
node index.js
```
