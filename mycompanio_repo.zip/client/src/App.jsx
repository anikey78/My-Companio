import { useState } from "react";
import "./index.css";

function App() {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);

  const sendMessage = async () => {
    if (!message.trim()) return;
    const userMsg = { sender: "You", text: message };
    setChat([...chat, userMsg]);

    const res = await fetch("http://localhost:4000/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();

    setChat((prev) => [...prev, { sender: "MyCompanio", text: data.reply }]);
    setMessage("");
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center">
      <header className="flex items-center p-4 bg-gray-800 w-full shadow-md">
        <img src="/logo.jpg" alt="logo" className="h-12 mr-3" />
        <h1 className="text-xl font-bold">MyCompanio</h1>
      </header>

      <div className="flex-1 w-full max-w-xl p-4 overflow-y-auto">
        {chat.map((c, i) => (
          <div key={i} className={`my-2 ${c.sender === "You" ? "text-right" : "text-left"}`}>
            <span className={`px-3 py-2 rounded-lg ${c.sender === "You" ? "bg-blue-600" : "bg-green-700"}`}>
              <b>{c.sender}:</b> {c.text}
            </span>
          </div>
        ))}
      </div>

      <div className="flex w-full max-w-xl p-4">
        <input
          className="flex-1 p-2 text-black rounded-l-lg"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message..."
        />
        <button className="bg-blue-500 px-4 rounded-r-lg" onClick={sendMessage}>
          Send
        </button>
      </div>
    </div>
  );
}

export default App;
