const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/chat", (req, res) => {
  const { message } = req.body || {};
  if (!message) {
    return res.json({ reply: "I'm here. Tell me how you feel." });
  }

  const msg = message.toLowerCase();
  if (msg.includes("sad")) {
    return res.json({ reply: "I'm sorry you're feeling sad. Would you like to try a breathing exercise?" });
  } else if (msg.includes("anxiety")) {
    return res.json({ reply: "That sounds tough. Try 4-7-8 breathing: Inhale 4, Hold 7, Exhale 8." });
  }

  return res.json({ reply: "Thanks for sharing. I'm listening." });
});

app.listen(4000, () => console.log("Server running on http://localhost:4000"));
